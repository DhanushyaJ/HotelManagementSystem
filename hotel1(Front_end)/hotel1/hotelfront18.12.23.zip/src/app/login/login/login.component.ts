import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { OwnerFunctionsService } from '../../owner-functions/owner-functions.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

 constructor(private router:Router){}

 loginForm = new FormGroup({
  id: new FormControl('', [Validators.required, Validators.maxLength(30)]),
  psw: new FormControl('', [Validators.required, Validators.maxLength(30)]),
});

  login(insert: any) {
    console.log(this.loginForm);
  }
  get id() {
    return this.loginForm.get('id');
  }
  get psw() {
    return this.loginForm.get('psw');
  }

  submit() {
    // if (this.id?.value?.length == 0 || this.psw?.value?.length == 0 || this.id?.invalid || this.psw?.invalid) {
    //   alert("Enter Valid Details");
    // }
    // if (this.id?.value == '101' && this.psw?.value == '1234') {
      //alert("Successfully Logged in")
      this.router.navigateByUrl('/owner');
    //}
   // else {
      // this.ps.getuser(this.loginForm.value).subscribe(
      //   data => {
      //     this.ps.getuser(this.loginForm.value).subscribe()
      //     localStorage.setItem('currentUser', JSON.stringify({ userid: this.id?.value }));
      //     alert("Successfully Logged in")
      //     this.router.navigate(['/userhome']);
      //   },
       // error => {
         // alert
          //  ("Invalid Credential");


       // }

      
    //}
  }

}
